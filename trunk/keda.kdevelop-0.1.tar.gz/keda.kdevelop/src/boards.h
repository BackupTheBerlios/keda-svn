/****************************************************************************
** Form interface generated from reading ui file '/home/bastl/Kdevel/keda/src/boards.ui'
**
** Created: Sa Apr 21 20:18:57 2007
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.5   edited Aug 31 12:13 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef BOARDS_H
#define BOARDS_H

#include <qvariant.h>
#include <qwidget.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;

class Boards : public QWidget
{
    Q_OBJECT

public:
    Boards( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~Boards();


protected:

protected slots:
    virtual void languageChange();

};

#endif // BOARDS_H
